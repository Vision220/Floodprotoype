import os
import json
import logging
from typing import Tuple, Optional
from app.services.gee.gee_config import GEEConfig

logger = logging.getLogger("FloodHADR.GEEAuth")

class GEEAuth:
    _initialized = False
    _authenticated = False
    _project_id: Optional[str] = None
    _status_message = "Google Earth Engine not configured"

    @classmethod
    def initialize(cls) -> Tuple[bool, str]:
        """
        Server-side authentication for Google Earth Engine.
        Fails gracefully if credentials are not present or invalid.
        """
        if cls._initialized:
            return cls._authenticated, cls._status_message

        cls._initialized = True
        project_id = GEEConfig.PROJECT_ID or os.getenv("GEE_PROJECT_ID")
        service_account = GEEConfig.SERVICE_ACCOUNT or os.getenv("GEE_SERVICE_ACCOUNT")
        private_key = GEEConfig.PRIVATE_KEY or os.getenv("GEE_PRIVATE_KEY")
        cred_file = GEEConfig.CREDENTIALS_FILE or os.getenv("GEE_CREDENTIALS_FILE")

        try:
            import ee
            if cred_file and os.path.exists(cred_file):
                logger.info(f"Authenticating GEE using service account file: {cred_file}")
                credentials = ee.ServiceAccountCredentials(service_account, cred_file)
                ee.Initialize(credentials, project=project_id)
                cls._authenticated = True
                cls._project_id = project_id or "service-account-auth"
                cls._status_message = "Google Earth Engine authenticated via service account file"
                return True, cls._status_message

            elif service_account and private_key:
                logger.info(f"Authenticating GEE using inline service account credentials: {service_account}")
                credentials = ee.ServiceAccountCredentials(service_account, key_data=private_key)
                ee.Initialize(credentials, project=project_id)
                cls._authenticated = True
                cls._project_id = project_id
                cls._status_message = "Google Earth Engine authenticated via inline service account"
                return True, cls._status_message

            else:
                # Attempt default local EE initialization if user logged in via 'earthengine authenticate'
                try:
                    ee.Initialize(project=project_id)
                    cls._authenticated = True
                    cls._project_id = project_id or "default-user-auth"
                    cls._status_message = "Google Earth Engine authenticated via local user profile"
                    return True, cls._status_message
                except Exception as local_err:
                    cls._authenticated = False
                    cls._status_message = f"GEE Credentials missing. Local init failed: {str(local_err)}"
                    logger.warning(cls._status_message)
                    return False, cls._status_message

        except ModuleNotFoundError:
            cls._authenticated = False
            cls._status_message = "earthengine-api Python package is not installed."
            logger.warning(cls._status_message)
            return False, cls._status_message

        except Exception as e:
            cls._authenticated = False
            cls._status_message = f"Google Earth Engine auth error: {str(e)}"
            logger.error(cls._status_message)
            return False, cls._status_message

    @classmethod
    def get_status(cls) -> dict:
        auth_status, msg = cls.initialize()
        
        if auth_status:
            status_code = "LIVE"
            status_message = f"Google Earth Engine LIVE — Connected ({cls._project_id})"
        elif "missing" in msg.lower() or "not configured" in msg.lower() or "not installed" in msg.lower():
            status_code = "UNAVAILABLE"
            status_message = "Google Earth Engine unavailable — DEMO/LOCAL DATA"
        elif "error" in msg.lower() or "failed" in msg.lower():
            status_code = "ERROR"
            status_message = f"Google Earth Engine error: {msg} — DEMO/LOCAL DATA"
        else:
            status_code = "DEMO"
            status_message = "Google Earth Engine unavailable — DEMO/LOCAL DATA"

        return {
            "status": status_code,
            "execution_state": status_code,
            "gee_execution_state": status_code,
            "authenticated": auth_status,
            "project": cls._project_id or (GEEConfig.PROJECT_ID or "NOT_CONFIGURED"),
            "service": "Google Earth Engine Remote Sensing Catalog",
            "message": status_message,
            "raw_message": msg,
            "mode": "LIVE" if auth_status else "DEMO",
            "separated_roles": {
                "A_hydrodynamic_simulation": "EXPLICITLY_DISABLED_IN_GEE (Main dam-break hydraulic solution solved exclusively by 2D finite-volume SWE/DWE solver)",
                "B_satellite_observation": "Sentinel-1 SAR & Sentinel-2 Optical Remote Sensing",
                "C_rainfall_remote_sensing": "CHIRPS Daily Satellite Precipitation Time-Series",
                "D_land_cover": "ESA WorldCover & Sentinel-2 NDVI Vegetation Index",
                "E_flood_extent_validation": "3-Way Spatial Comparison (GEE SAR vs FloodHADR vs HEC-RAS)"
            }
        }
