import React from 'react';
import { ShieldCheck, Info, AlertTriangle, AlertCircle, FileText } from 'lucide-react';

export type ProvenanceStatus = 
  | 'OFFICIAL'
  | 'OBSERVED'
  | 'HISTORICAL'
  | 'DERIVED'
  | 'SCENARIO'
  | 'SYNTHETIC'
  | 'DEMO'
  | 'EXPERIMENTAL'
  | 'UNVERIFIED'
  | 'SITE_SPECIFIC_REQUIRED';

interface DataProvenanceBadgeProps {
  status: ProvenanceStatus;
  source?: string;
  tooltipNotes?: string;
  alternateValues?: Array<{ value: any; source: string; status: string; notes?: string }>;
}

export const DataProvenanceBadge: React.FC<DataProvenanceBadgeProps> = ({
  status,
  source,
  tooltipNotes,
  alternateValues
}) => {
  const getBadgeStyle = () => {
    switch (status) {
      case 'OFFICIAL':
        return {
          bg: 'bg-emerald-950/80',
          text: 'text-emerald-300',
          border: 'border-emerald-500/40',
          dot: 'bg-emerald-400',
          label: 'OFFICIAL',
          icon: ShieldCheck
        };
      case 'OBSERVED':
        return {
          bg: 'bg-teal-950/80',
          text: 'text-teal-300',
          border: 'border-teal-500/40',
          dot: 'bg-teal-400',
          label: 'OBSERVED',
          icon: ShieldCheck
        };
      case 'HISTORICAL':
        return {
          bg: 'bg-sky-950/80',
          text: 'text-sky-300',
          border: 'border-sky-500/40',
          dot: 'bg-sky-400',
          label: 'HISTORICAL',
          icon: FileText
        };
      case 'DERIVED':
        return {
          bg: 'bg-purple-950/80',
          text: 'text-purple-300',
          border: 'border-purple-500/40',
          dot: 'bg-purple-400',
          label: 'DERIVED',
          icon: Info
        };
      case 'SCENARIO':
        return {
          bg: 'bg-indigo-950/80',
          text: 'text-indigo-300',
          border: 'border-indigo-500/40',
          dot: 'bg-indigo-400',
          label: 'SCENARIO',
          icon: Info
        };
      case 'SITE_SPECIFIC_REQUIRED':
        return {
          bg: 'bg-amber-950/80',
          text: 'text-amber-300',
          border: 'border-amber-500/40',
          dot: 'bg-amber-400 animate-pulse',
          label: 'SITE-SPECIFIC REQUIRED',
          icon: AlertTriangle
        };
      case 'SYNTHETIC':
      case 'DEMO':
        return {
          bg: 'bg-slate-950',
          text: 'text-slate-400',
          border: 'border-slate-800',
          dot: 'bg-slate-400',
          label: 'DEMO / SYNTHETIC',
          icon: AlertCircle
        };
      default:
        return {
          bg: 'bg-slate-900',
          text: 'text-slate-300',
          border: 'border-slate-700',
          dot: 'bg-slate-400',
          label: status,
          icon: Info
        };
    }
  };

  const style = getBadgeStyle();
  const IconComponent = style.icon;

  return (
    <div className="group relative inline-flex items-center">
      <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${style.bg} ${style.text} ${style.border}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${style.dot}`} />
        <IconComponent className="w-3 h-3 shrink-0" />
        <span>{style.label}</span>
      </span>

      {/* Tooltip on Hover */}
      {(source || tooltipNotes || (alternateValues && alternateValues.length > 0)) && (
        <div className="absolute left-0 bottom-full mb-1.5 hidden group-hover:block z-50 w-64 p-2.5 bg-slate-950 border border-slate-700 rounded-xl shadow-2xl text-[10px] font-mono text-slate-300 space-y-1">
          {source && (
            <div className="font-bold text-white border-b border-slate-800 pb-1">
              Source: <span className="text-sky-300 font-normal">{source}</span>
            </div>
          )}
          {tooltipNotes && (
            <div className="text-slate-400 leading-tight">
              {tooltipNotes}
            </div>
          )}
          {alternateValues && alternateValues.length > 0 && (
            <div className="pt-1 border-t border-slate-800 space-y-0.5">
              <div className="text-[9px] text-amber-400 font-bold uppercase">Alternate Source Discrepancy:</div>
              {alternateValues.map((alt, idx) => (
                <div key={idx} className="text-slate-400">
                  • <span className="text-slate-200">{alt.value}</span> ({alt.source}): {alt.notes || alt.status}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
