/**
 * Authoritative Tehri Dam & Reservoir Engineering Data Model (Frontend)
 * Single Source of Truth matching backend/app/data/tehri_authoritative.py
 */

export interface ProvenanceItem {
  parameter: string;
  category: string;
  label: string;
  value: any;
  unit: string;
  status: 'OFFICIAL' | 'OBSERVED' | 'HISTORICAL' | 'DERIVED' | 'SCENARIO' | 'SYNTHETIC' | 'EXPERIMENTAL' | 'UNVERIFIED' | 'SITE_SPECIFIC_REQUIRED';
  source: string;
  source_url?: string;
  provenance: string;
  confidence: number;
  verification_status: string;
  date?: string;
  notes?: string;
  alternate_values?: Array<{
    value: any;
    source: string;
    status: string;
    notes?: string;
  }>;
}

export const TEHRI_AUTHORITATIVE_DATA: Record<string, ProvenanceItem> = {
  // 1. Dam Engineering
  dam_name: {
    parameter: 'dam_name',
    category: 'Dam Engineering',
    label: 'Dam Name',
    value: 'Tehri Dam',
    unit: 'text',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Multi-purpose earth and rockfill dam on Bhagirathi River in Tehri Garhwal district.'
  },
  river: {
    parameter: 'river',
    category: 'Dam Engineering',
    label: 'Primary River',
    value: 'Bhagirathi River',
    unit: 'text',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Principal headstream of the Ganges River.'
  },
  tributary_bhilangana: {
    parameter: 'tributary_bhilangana',
    category: 'Dam Engineering',
    label: 'Major Contributing River',
    value: 'Bhilangana River',
    unit: 'text',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Major left-bank tributary joining Bhagirathi River at Tehri Reservoir.'
  },
  tributary_balganga: {
    parameter: 'tributary_balganga',
    category: 'Dam Engineering',
    label: 'Additional Contributing System',
    value: 'Balganga River',
    unit: 'text',
    status: 'OFFICIAL',
    source: 'CWC / Uttarakhand Jal Sansthan',
    source_url: 'https://cwc.gov.in',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Sub-tributary contributing to the Bhilangana basin upstream.'
  },
  dam_type: {
    parameter: 'dam_type',
    category: 'Dam Engineering',
    label: 'Dam Structural Type',
    value: 'Earth and Rockfill Dam',
    unit: 'text',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Central clay core earth-fill embankment with rockfill shell.'
  },
  dam_height: {
    parameter: 'dam_height',
    category: 'Dam Engineering',
    label: 'Dam Height',
    value: 260.5,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Tallest dam in India and 5th tallest dam in the world.'
  },
  dam_top_crest_elevation: {
    parameter: 'dam_top_crest_elevation',
    category: 'Dam Engineering',
    label: 'Dam Crest / Top Level',
    value: 839.5,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'EL 839.5 m is Dam Crest / Top level. DO NOT label 839.5 m as MFL or PMF.'
  },
  crest_length: {
    parameter: 'crest_length',
    category: 'Dam Engineering',
    label: 'Crest / Top Length',
    value: 575.0,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Official embankment crest length.'
  },
  top_width: {
    parameter: 'top_width',
    category: 'Dam Engineering',
    label: 'Top Width',
    value: 25.5,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    source_url: 'https://thdc.co.in/en/project/tehri-hep-1000-mw',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Roadway top width at crest level.'
  },
  top_width_abutments: {
    parameter: 'top_width_abutments',
    category: 'Dam Engineering',
    label: 'Top Width at Abutments',
    value: 30.5,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Top width expanded at abutment contacts.'
  },
  riverbed_base_width: {
    parameter: 'riverbed_base_width',
    category: 'Dam Engineering',
    label: 'Riverbed / Base Width',
    value: 1125.0,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Maximum base width at riverbed footprint.'
  },
  upstream_slope: {
    parameter: 'upstream_slope',
    category: 'Dam Engineering',
    label: 'Upstream Slope',
    value: '1V : 2.5H',
    unit: 'V:H',
    status: 'OFFICIAL',
    source: 'THDC Structural Design Manual',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Upstream slope 1 Vertical to 2.5 Horizontal.'
  },
  downstream_slope: {
    parameter: 'downstream_slope',
    category: 'Dam Engineering',
    label: 'Downstream Slope',
    value: '1V : 2H',
    unit: 'V:H',
    status: 'OFFICIAL',
    source: 'THDC Structural Design Manual',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Downstream slope 1 Vertical to 2.0 Horizontal.'
  },

  // 2. Reservoir Levels (UI Order: Crest -> MFL -> FRL -> MDDL)
  dam_crest_level: {
    parameter: 'dam_crest_level',
    category: 'Reservoir Levels',
    label: 'DAM CREST / TOP',
    value: 839.5,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'EL 839.5 m — Top Crest Elevation. Provides freeboard above MFL and FRL.'
  },
  mfl: {
    parameter: 'mfl',
    category: 'Reservoir Levels',
    label: 'MAXIMUM FLOOD LEVEL (MFL)',
    value: 835.0,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'EL 835.0 m — Maximum flood surcharge operating level during PMF routing.'
  },
  frl: {
    parameter: 'frl',
    category: 'Reservoir Levels',
    label: 'FULL RESERVOIR LEVEL (FRL)',
    value: 830.0,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    date: '2021-09-24',
    notes: 'EL 830.0 m — Normal maximum operating level. Documented FRL Achievement on 24 September 2021.'
  },
  mddl: {
    parameter: 'mddl',
    category: 'Reservoir Levels',
    label: 'MINIMUM DRAW-DOWN LEVEL (MDDL)',
    value: 740.0,
    unit: 'm',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'EL 740.0 m — Minimum drawdown pool for power intake operation.'
  },

  // 3. Storage Capacity
  gross_storage: {
    parameter: 'gross_storage',
    category: 'Storage',
    label: 'Gross Reservoir Storage',
    value: 3540.0,
    unit: 'MCM',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Total reservoir capacity at FRL EL 830 m (3540 MCM).'
  },
  live_storage: {
    parameter: 'live_storage',
    category: 'Storage',
    label: 'Live Storage',
    value: 2615.0,
    unit: 'MCM',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Active storage capacity between MDDL 740 m and FRL 830 m (2615 MCM).'
  },
  dead_storage: {
    parameter: 'dead_storage',
    category: 'Storage',
    label: 'Dead Storage',
    value: 925.0,
    unit: 'MCM',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Dead storage volume below MDDL 740 m reserved for siltation (925 MCM).'
  },

  // 4. Power Capacity
  tehri_hpp_capacity: {
    parameter: 'tehri_hpp_capacity',
    category: 'Power Capacity',
    label: 'Tehri HPP Stage-I Installed Capacity',
    value: 1000.0,
    unit: 'MW',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Tehri Stage-I generating capacity: 4 × 250 MW Francis units.'
  },
  tehri_hydro_complex_total: {
    parameter: 'tehri_hydro_complex_total',
    category: 'Power Capacity',
    label: 'Tehri Hydro Power Complex Total',
    value: 2400.0,
    unit: 'MW',
    status: 'OFFICIAL',
    source: 'THDC India Limited (THDCIL)',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Total complex capacity (Tehri Stage-I 1000 MW + PSP 1000 MW + Koteshwar 400 MW). Do not display 2400 MW as Stage-I capacity.'
  },

  // 5. Catchment Area
  catchment_area: {
    parameter: 'catchment_area',
    category: 'Catchment',
    label: 'Catchment Area at Tehri Dam Axis',
    value: 7293.0,
    unit: 'km²',
    status: 'OFFICIAL',
    source: 'Recent Tehri inflow forecasting study',
    provenance: 'OFFICIAL_REFERENCE_STUDY',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Primary catchment: Bhagirathi 5,807 km², Bhilangana 1,486 km².',
    alternate_values: [
      {
        value: 7511.0,
        source: 'CWC historical project document',
        status: 'HISTORICAL_REFERENCE',
        notes: 'Historical CWC documentation reports 7,511 km². Values differ by source definition/reference dataset.'
      }
    ]
  },

  // 6. Flood & Discharge Data
  pmf_design_flood: {
    parameter: 'pmf_design_flood',
    category: 'Flood / PMF',
    label: 'DESIGN FLOOD PMF',
    value: 15540.0,
    unit: 'm³/s',
    status: 'OFFICIAL',
    source: 'THDC / Central Water Commission',
    provenance: 'OFFICIAL_GOVERNMENT_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Probable Maximum Flood (PMF) design inflow discharge. NEVER call historically observed discharge.'
  },
  routed_design_flood: {
    parameter: 'routed_design_flood',
    category: 'Flood / PMF',
    label: 'ROUTED DESIGN FLOOD',
    value: 13040.0,
    unit: 'm³/s',
    status: 'OFFICIAL',
    source: 'THDC Flood Routing DPR',
    provenance: 'OFFICIAL_ROUTING_STUDY',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    notes: 'Peak spillway outflow discharge after reservoir attenuation (~13,040 m³/s).'
  },
  historical_recorded_flood: {
    parameter: 'historical_recorded_flood',
    category: 'Flood / PMF',
    label: 'HISTORICAL RECORDED FLOOD',
    value: 3800.0,
    unit: 'm³/s',
    status: 'OBSERVED',
    source: 'CWC / THDC Gauge Records',
    provenance: 'OBSERVED_GAUGE_RECORD',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    date: '2010-09-19',
    notes: 'Maximum recorded historical observed flood discharge at Tehri gauge. NEVER call PMF.'
  },

  // 7. Foundation Elevation (CRITICAL CORRECTION)
  foundation_elevation: {
    parameter: 'foundation_elevation',
    category: 'Geotechnical Foundation',
    label: 'Foundation Elevation',
    value: null,
    unit: 'm MSL',
    status: 'SITE_SPECIFIC_REQUIRED',
    source: 'Site-specific engineering datum required',
    provenance: 'UNAVAILABLE',
    confidence: 0.0,
    verification_status: 'SITE_SPECIFIC_REQUIRED',
    notes: '569.5 m and 579.0 m removed as arbitrary derived numbers (830 - 260.5). Site-specific engineering drawing/DPR datum required.'
  },

  // 8. Groundwater Information
  groundwater_district_monitoring: {
    parameter: 'groundwater_district_monitoring',
    category: 'Groundwater',
    label: 'CGWB Tehri Garhwal District Monitoring',
    value: '31.27 – 76.63',
    unit: 'm bgl',
    status: 'OBSERVED',
    source: 'Central Ground Water Board (CGWB)',
    provenance: 'OBSERVED_MONITORING_WELLS',
    confidence: 1.0,
    verification_status: 'VERIFIED',
    date: '2024-01',
    notes: 'CGWB monitored groundwater depth across 5 monitoring wells in Tehri Garhwal district (Jan 2024). NOT a dam-site measurement.'
  },
  groundwater_damsite: {
    parameter: 'groundwater_damsite',
    category: 'Groundwater',
    label: 'Dam-Site Groundwater Table',
    value: null,
    unit: 'm bgl',
    status: 'SITE_SPECIFIC_REQUIRED',
    source: 'Site-specific measurement required',
    provenance: 'UNAVAILABLE',
    confidence: 0.0,
    verification_status: 'SITE_SPECIFIC_REQUIRED',
    notes: 'Dam-site piezometer record required.'
  },

  // 9. Liquefaction Assessment
  liquefaction_assessment: {
    parameter: 'liquefaction_assessment',
    category: 'Geotechnical Hazard',
    label: 'Liquefaction Susceptibility',
    value: 'SITE-SPECIFIC GEOTECHNICAL ASSESSMENT REQUIRED',
    unit: 'text',
    status: 'SITE_SPECIFIC_REQUIRED',
    source: 'Geotechnical field testing required (SPT / CPT / Vs30 / PGA)',
    provenance: 'UNAVAILABLE',
    confidence: 0.0,
    verification_status: 'SITE_SPECIFIC_REQUIRED',
    notes: 'Requires site-specific SPT N-values, CPT data, fines content, and cyclic loading analysis. Must not be inferred from DEM alone.'
  }
};

export const RESERVOIR_LEVELS_ORDERED = [
  { level_m: 839.5, label: 'EL 839.5 m — DAM CREST / TOP', code: 'CREST', badge: 'OFFICIAL', color: '#ef4444' },
  { level_m: 835.0, label: 'EL 835.0 m — MAXIMUM FLOOD LEVEL (MFL)', code: 'MFL', badge: 'OFFICIAL', color: '#f97316' },
  { level_m: 830.0, label: 'EL 830.0 m — FULL RESERVOIR LEVEL (FRL)', code: 'FRL', badge: 'OFFICIAL', color: '#3b82f6', subtitle: 'Documented Achievement 24 Sept 2021' },
  { level_m: 740.0, label: 'EL 740.0 m — MINIMUM DRAW-DOWN LEVEL (MDDL)', code: 'MDDL', badge: 'OFFICIAL', color: '#38bdf8' }
];

export const DISASTER_CLASSIFICATION = {
  natural_hazards: {
    hydrometeorological: ['Extreme Rainfall', 'Cloudburst', 'Flash Flood', 'River Flood'],
    geological: ['Landslide', 'Rockfall', 'Slope Failure', 'Earthquake', 'GLOF Scenario']
  },
  dam_failure_scenarios: [
    { code: 'OVERTOPPING', name: 'Overtopping Breach Scenario', status: 'SCENARIO' },
    { code: 'PIPING', name: 'Piping / Internal Erosion Scenario', status: 'SCENARIO' },
    { code: 'PARTIAL_BREACH', name: 'Partial Structural Breach Scenario', status: 'SCENARIO' },
    { code: 'RAPID_BREACH', name: 'Rapid Full Breach Scenario', status: 'SCENARIO' },
    { code: 'LANDSLIDE_WAVE', name: 'Landslide Impulse Wave Scenario', status: 'SCENARIO' },
    { code: 'SPILLWAY_FAILURE', name: 'Spillway Gating Failure Scenario', status: 'SCENARIO' },
    { code: 'OUTLET_TUNNEL_FAILURE', name: 'Outlet Tunnel Failure Scenario', status: 'SCENARIO' }
  ],
  human_technological: ['Infrastructure Collapse', 'Bridge Failure', 'Roadway Blockage', 'Utility Grid Failure', 'Hazardous Spill']
};
