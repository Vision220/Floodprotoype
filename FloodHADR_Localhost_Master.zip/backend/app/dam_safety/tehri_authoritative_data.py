"""
Authoritative Tehri Dam Engineering Parameter Database
Primary Source: THDC India Limited (THDCIL) Official Project Records,
Central Water Commission (CWC) National Register of Large Dams (NRLD).
"""

from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

from app.data.tehri_authoritative import (
    TEHRI_AUTHORITATIVE_DATA,
    get_authoritative_tehri_parameter_list,
    ParameterProvenance
)

class DamParameterSchema(BaseModel):
    parameter: str = Field(..., description="Canonical parameter identifier key")
    category: str = Field(..., description="Dam Engineering | Reservoir Levels | Storage | Spillway | Tehri HPP | Geotechnical Foundation | Catchment | Flood / PMF | Groundwater | Geotechnical Hazard | Soil & Geology")
    label: str = Field(..., description="Human-readable parameter name")
    value: Any = Field(..., description="Numerical value, specification string, or None if site-specific data is required")
    unit: str = Field(..., description="Measurement unit (e.g. m, MCM, m3/s, MW, km²)")
    status: str = Field(..., description="OFFICIAL | OBSERVED | HISTORICAL | DERIVED | SCENARIO | SYNTHETIC | EXPERIMENTAL | UNVERIFIED | SITE_SPECIFIC_REQUIRED")
    source: str = Field(..., description="Primary authoritative source document or agency")
    source_url: Optional[str] = Field(None, description="Verifiable web reference URL")
    provenance: str = Field(..., description="OFFICIAL_GOVERNMENT_RECORD | OBSERVED_GAUGE_RECORD | DERIVED | SITE_SPECIFIC_REQUIRED | SCENARIO")
    confidence: float = Field(1.0, ge=0.0, le=1.0, description="Confidence score between 0.0 and 1.0")
    verification_status: str = Field(..., description="VERIFIED | PARTIALLY_VERIFIED | REQUIRES_VERIFICATION | UNVERIFIED | SITE_SPECIFIC_REQUIRED")
    date: Optional[str] = Field(None, description="ISO date of observation or document release")
    notes: Optional[str] = Field(None, description="Technical notes or provenance explanation")
    alternate_values: Optional[List[Dict[str, Any]]] = Field(None, description="Discrepancy audit list for historical or alternate sources")

TEHRI_AUTHORITATIVE_PARAMETERS: List[Dict[str, Any]] = list(TEHRI_AUTHORITATIVE_DATA.values())

def get_authoritative_tehri_parameters() -> List[DamParameterSchema]:
    """Returns validated list of DamParameterSchema objects."""
    return [DamParameterSchema(**p) for p in TEHRI_AUTHORITATIVE_PARAMETERS]
