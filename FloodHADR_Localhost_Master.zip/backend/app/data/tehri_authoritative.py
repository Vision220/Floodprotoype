"""
Central Authoritative Tehri Dam & Reservoir Engineering Data Model
Primary Source: THDC India Limited (THDCIL), Central Water Commission (CWC), CGWB, GSI.
"""

from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

class AlternateValue(BaseModel):
    value: Any
    source: str
    status: str
    notes: Optional[str] = None

class ParameterProvenance(BaseModel):
    parameter: str
    category: str
    label: str
    value: Any
    unit: str
    status: str  # OFFICIAL | OBSERVED | HISTORICAL | DERIVED | SCENARIO | SYNTHETIC | EXPERIMENTAL | UNVERIFIED | SITE_SPECIFIC_REQUIRED
    source: str
    source_url: Optional[str] = None
    provenance: str
    confidence: float = 1.0
    verification_status: str  # VERIFIED | PARTIALLY_VERIFIED | REQUIRES_VERIFICATION | UNVERIFIED | SITE_SPECIFIC_REQUIRED
    date: Optional[str] = None
    notes: Optional[str] = None
    alternate_values: Optional[List[AlternateValue]] = None

# Authoritative Tehri Parameters Dictionary
TEHRI_AUTHORITATIVE_DATA: Dict[str, Dict[str, Any]] = {
    # 1. Dam Engineering
    "dam_name": {
        "parameter": "dam_name",
        "category": "Dam Engineering",
        "label": "Dam Name",
        "value": "Tehri Dam",
        "unit": "text",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Primary multi-purpose embankment dam on Bhagirathi River in Tehri Garhwal."
    },
    "river": {
        "parameter": "river",
        "category": "Dam Engineering",
        "label": "Primary River",
        "value": "Bhagirathi River",
        "unit": "text",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Principal headstream of the Ganga River."
    },
    "tributary_bhilangana": {
        "parameter": "tributary_bhilangana",
        "category": "Dam Engineering",
        "label": "Major Contributing River",
        "value": "Bhilangana River",
        "unit": "text",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Major left-bank tributary joining Bhagirathi at the Tehri reservoir pool."
    },
    "tributary_balganga": {
        "parameter": "tributary_balganga",
        "category": "Dam Engineering",
        "label": "Additional Contributing System",
        "value": "Balganga River",
        "unit": "text",
        "status": "OFFICIAL",
        "source": "CWC / Uttarakhand Jal Sansthan",
        "source_url": "https://cwc.gov.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Sub-tributary flowing into Bhilangana upstream of Tehri reservoir."
    },
    "dam_type": {
        "parameter": "dam_type",
        "category": "Dam Engineering",
        "label": "Dam Type",
        "value": "Earth and Rockfill Dam",
        "unit": "text",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Central clay core earth-fill embankment with rockfill shell."
    },
    "dam_height": {
        "parameter": "dam_height",
        "category": "Dam Engineering",
        "label": "Dam Height",
        "value": 260.5,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Tallest dam in India and 5th tallest dam in the world."
    },
    "dam_top_crest_elevation": {
        "parameter": "dam_top_crest_elevation",
        "category": "Dam Engineering",
        "label": "Dam Crest / Top Level",
        "value": 839.5,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "EL 839.5 m is the official embankment crest/top level. DO NOT label as MFL or PMF."
    },
    "crest_length": {
        "parameter": "crest_length",
        "category": "Dam Engineering",
        "label": "Crest / Top Length",
        "value": 575.0,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Official crest length across dam axis."
    },
    "top_width": {
        "parameter": "top_width",
        "category": "Dam Engineering",
        "label": "Top Width",
        "value": 25.5,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Top width at dam roadway section. Abutment width expands to 30.5 m."
    },
    "top_width_abutments": {
        "parameter": "top_width_abutments",
        "category": "Dam Engineering",
        "label": "Top Width at Abutments",
        "value": 30.5,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Expanded embankment top width at abutment contacts."
    },
    "riverbed_base_width": {
        "parameter": "riverbed_base_width",
        "category": "Dam Engineering",
        "label": "Riverbed / Base Width",
        "value": 1125.0,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Maximum base footprint width in river valley."
    },
    "upstream_slope": {
        "parameter": "upstream_slope",
        "category": "Dam Engineering",
        "label": "Upstream Embankment Slope",
        "value": "1V : 2.5H",
        "unit": "V:H",
        "status": "OFFICIAL",
        "source": "THDC India Limited Structural Profile",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Upstream slope profile 1 Vertical to 2.5 Horizontal."
    },
    "downstream_slope": {
        "parameter": "downstream_slope",
        "category": "Dam Engineering",
        "label": "Downstream Embankment Slope",
        "value": "1V : 2H",
        "unit": "V:H",
        "status": "OFFICIAL",
        "source": "THDC India Limited Structural Profile",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Downstream slope profile 1 Vertical to 2.0 Horizontal."
    },

    # 2. Reservoir Levels
    "mddl": {
        "parameter": "mddl",
        "category": "Reservoir Levels",
        "label": "Minimum Draw-Down Level (MDDL)",
        "value": 740.0,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Lowest operational level for Francis turbine power intakes."
    },
    "frl": {
        "parameter": "frl",
        "category": "Reservoir Levels",
        "label": "Full Reservoir Level (FRL)",
        "value": 830.0,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "date": "2021-09-24",
        "notes": "Normal maximum operating conservation pool level. Documented FRL achievement on 24 Sept 2021."
    },
    "mfl": {
        "parameter": "mfl",
        "category": "Reservoir Levels",
        "label": "Maximum Flood Level (MFL)",
        "value": 835.0,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Maximum water level during PMF routing with spillways fully operating."
    },
    "dam_crest_level": {
        "parameter": "dam_crest_level",
        "category": "Reservoir Levels",
        "label": "Dam Crest / Top",
        "value": 839.5,
        "unit": "m",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Embankment crest level providing 4.5m freeboard above MFL (835.0m) and 9.5m above FRL (830.0m)."
    },

    # 3. Storage Capacity
    "gross_storage": {
        "parameter": "gross_storage",
        "category": "Storage",
        "label": "Gross Reservoir Storage",
        "value": 3540.0,
        "unit": "MCM",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Total storage capacity at FRL EL 830 m in Million Cubic Metres (MCM)."
    },
    "live_storage": {
        "parameter": "live_storage",
        "category": "Storage",
        "label": "Live Storage",
        "value": 2615.0,
        "unit": "MCM",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Active usable storage pool between MDDL (740m) and FRL (830m)."
    },
    "dead_storage": {
        "parameter": "dead_storage",
        "category": "Storage",
        "label": "Dead Storage",
        "value": 925.0,
        "unit": "MCM",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Inactive storage volume below MDDL EL 740 m reserved for sediment accumulation."
    },

    # 4. Power Capacity
    "tehri_hpp_capacity": {
        "parameter": "tehri_hpp_capacity",
        "category": "Power Capacity",
        "label": "Tehri HPP Stage-I Installed Capacity",
        "value": 1000.0,
        "unit": "MW",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Tehri Stage-I Underground HPP installed capacity: 4 × 250 MW Francis units."
    },
    "tehri_hpp_configuration": {
        "parameter": "tehri_hpp_configuration",
        "category": "Power Capacity",
        "label": "Tehri HPP Generating Units",
        "value": "4 × 250 MW",
        "unit": "text",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in/en/project/tehri-hep-1000-mw",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "4 vertical Francis turbine generator sets."
    },
    "tehri_hydro_complex_total": {
        "parameter": "tehri_hydro_complex_total",
        "category": "Power Capacity",
        "label": "Tehri Hydro Power Complex Total",
        "value": 2400.0,
        "unit": "MW",
        "status": "OFFICIAL",
        "source": "THDC India Limited (THDCIL)",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Combined complex including Tehri Stage-I (1000 MW), Tehri PSP (1000 MW), and Koteshwar HEP (400 MW). Do not label 2400 MW as Tehri Dam Stage-I capacity."
    },

    # 5. Catchment Area
    "catchment_area": {
        "parameter": "catchment_area",
        "category": "Catchment",
        "label": "Catchment Area at Dam Axis",
        "value": 7293.0,
        "unit": "km²",
        "status": "OFFICIAL/REFERENCE",
        "source": "Recent Tehri inflow forecasting study",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_REFERENCE_STUDY",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Primary catchment at Tehri Dam axis (Bhagirathi: 5,807 km², Bhilangana: 1,486 km²).",
        "alternate_values": [
            {
                "value": 7511.0,
                "source": "CWC historical project document",
                "status": "HISTORICAL_REFERENCE",
                "notes": "Historical CWC documentation reports 7,511 km². Values differ by source definition/reference dataset."
            }
        ]
    },

    # 6. Flood & Hydrograph
    "pmf_design_flood": {
        "parameter": "pmf_design_flood",
        "category": "Flood / PMF",
        "label": "Design Flood PMF",
        "value": 15540.0,
        "unit": "m³/s",
        "status": "OFFICIAL",
        "source": "THDC India Limited / Central Water Commission",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_GOVERNMENT_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Probable Maximum Flood (PMF) design inflow discharge. NEVER label as historically observed flood."
    },
    "routed_design_flood": {
        "parameter": "routed_design_flood",
        "category": "Flood / PMF",
        "label": "Routed Design Flood",
        "value": 13040.0,
        "unit": "m³/s",
        "status": "OFFICIAL",
        "source": "THDC Reservoir Flood Routing DPR",
        "source_url": "https://thdc.co.in",
        "provenance": "OFFICIAL_ROUTING_STUDY",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "notes": "Peak outflow spillway discharge after reservoir surcharge attenuation during PMF routing."
    },
    "historical_recorded_flood": {
        "parameter": "historical_recorded_flood",
        "category": "Flood / PMF",
        "label": "Historical Recorded Flood",
        "value": 3800.0,
        "unit": "m³/s",
        "status": "OBSERVED",
        "source": "CWC / THDC Historical Gauge Records",
        "source_url": "https://cwc.gov.in",
        "provenance": "OBSERVED_GAUGE_RECORD",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "date": "2010-09-19",
        "notes": "Maximum recorded historical observed flood discharge at Tehri gauge station. NEVER call this the PMF."
    },

    # 7. Foundation Elevation (CRITICAL CORRECTION)
    "foundation_elevation": {
        "parameter": "foundation_elevation",
        "category": "Geotechnical Foundation",
        "label": "Foundation Elevation",
        "value": None,
        "unit": "m MSL",
        "status": "SITE_SPECIFIC_REQUIRED",
        "source": "Site-specific engineering datum required",
        "source_url": None,
        "provenance": "UNAVAILABLE",
        "confidence": 0.0,
        "verification_status": "SITE_SPECIFIC_REQUIRED",
        "notes": "569.5 m and 579.0 m removed as arbitrary derived numbers (830 - 260.5 = 569.5). Site-specific engineering drawing/DPR datum required for authoritative foundation elevation."
    },

    # 8. Groundwater (CRITICAL CORRECTION)
    "groundwater_district_monitoring": {
        "parameter": "groundwater_district_monitoring",
        "category": "Groundwater",
        "label": "CGWB Tehri Garhwal District Groundwater",
        "value": "31.27 – 76.63",
        "unit": "m bgl",
        "status": "OBSERVED",
        "source": "Central Ground Water Board (CGWB) District Monitoring",
        "source_url": "https://cgwb.gov.in",
        "provenance": "OBSERVED_MONITORING_WELLS",
        "confidence": 1.0,
        "verification_status": "VERIFIED",
        "date": "2024-01",
        "notes": "CGWB monitored groundwater depth across 5 district monitoring wells in Tehri Garhwal (Jan 2024). NOT a dam-site measurement."
    },
    "groundwater_damsite": {
        "parameter": "groundwater_damsite",
        "category": "Groundwater",
        "label": "Dam-Site Groundwater Table",
        "value": None,
        "unit": "m bgl",
        "status": "SITE_SPECIFIC_REQUIRED",
        "source": "Site-specific measurement required",
        "source_url": None,
        "provenance": "UNAVAILABLE",
        "confidence": 0.0,
        "verification_status": "SITE_SPECIFIC_REQUIRED",
        "notes": "Dam-site groundwater piezometer record required. District monitoring data must not be labeled as dam-site groundwater."
    },

    # 9. Liquefaction Assessment
    "liquefaction_assessment": {
        "parameter": "liquefaction_assessment",
        "category": "Geotechnical Hazard",
        "label": "Liquefaction Susceptibility",
        "value": "SITE-SPECIFIC GEOTECHNICAL ASSESSMENT REQUIRED",
        "unit": "text",
        "status": "SITE_SPECIFIC_REQUIRED",
        "source": "Geotechnical field testing required (SPT / CPT / Vs30 / PGA)",
        "source_url": None,
        "provenance": "UNAVAILABLE",
        "confidence": 0.0,
        "verification_status": "SITE_SPECIFIC_REQUIRED",
        "notes": "Requires site-specific SPT N-values, CPT soundings, fines content, and cyclic loading calculation. Liquefaction must not be inferred from DEM alone."
    },

    # 10. Soil & Geology Classification
    "soil_geology_classification": {
        "parameter": "soil_geology_classification",
        "category": "Soil & Geology",
        "label": "Regional Terrain & Geology Classes",
        "value": "GIS Landform Based Soil/Lithology Map",
        "unit": "text",
        "status": "OFFICIAL/REFERENCE",
        "source": "Geological Survey of India (GSI) / NRSC Bhuvan",
        "source_url": "https://gsi.gov.in",
        "provenance": "OFFICIAL_GIS_LAYER",
        "confidence": 0.9,
        "verification_status": "VERIFIED",
        "notes": "Classes: Alluvial deposits (terrace/valley), Residual shallow soil (slopes), Colluvial soil over weathered rock (steep slopes), Weathered/fractured quartzite & phyllite rock (rocky ridges). Engineering parameters require geotechnical sampling."
    }
}

def get_authoritative_tehri_dict() -> Dict[str, Dict[str, Any]]:
    """Returns raw authoritative dictionary for Tehri Dam parameters."""
    return TEHRI_AUTHORITATIVE_DATA

def get_authoritative_tehri_parameter_list() -> List[ParameterProvenance]:
    """Returns validated list of ParameterProvenance objects."""
    res = []
    for k, v in TEHRI_AUTHORITATIVE_DATA.items():
        alt = None
        if "alternate_values" in v and v["alternate_values"]:
            alt = [AlternateValue(**a) for a in v["alternate_values"]]
        res.append(
            ParameterProvenance(
                parameter=v["parameter"],
                category=v["category"],
                label=v["label"],
                value=v["value"],
                unit=v["unit"],
                status=v["status"],
                source=v["source"],
                source_url=v.get("source_url"),
                provenance=v["provenance"],
                confidence=v.get("confidence", 1.0),
                verification_status=v["verification_status"],
                date=v.get("date"),
                notes=v.get("notes"),
                alternate_values=alt
            )
        )
    return res
