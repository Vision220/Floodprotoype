import unittest
import os
import sys
import asyncio
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from app.data.tehri_authoritative import (
    TEHRI_AUTHORITATIVE_DATA,
    get_authoritative_tehri_dict,
    get_authoritative_tehri_parameter_list
)
from app.dam_safety.tehri_authoritative_data import get_authoritative_tehri_parameters
from app.gis.dam_analyzer import get_tehri_dam_intelligence_data, compute_hydrostatic_parameters
from app.simulation.hydrodynamic_2d_solver import Hydrodynamic2DSolver, Hydrodynamic2DSolverConfig, SolverMode
from app.simulation.dam_break import DamBreachModel, BreachMode
from app.simulation.reservoir_operation_model import ReservoirOperationModel, ReservoirPreset
from app.services.gee.gee_auth import GEEAuth
from app.gis.gis_2d_service import GIS2DLayerService
from app.api.hecras import get_hecras_status

class TestPhase25TehriAuthoritativeData(unittest.TestCase):
    """
    Automated Test Suite for Tehri Dam Data, Engineering, Hazard & Geological Data Correction.
    Executes 26 non-negotiable scientific & engineering validation tests.
    """

    def setUp(self):
        self.data = get_authoritative_tehri_dict()

    def test_01_dam_height(self):
        """TEST 1: Dam height = 260.5 m"""
        self.assertEqual(self.data["dam_height"]["value"], 260.5)
        self.assertEqual(self.data["dam_height"]["unit"], "m")
        self.assertEqual(self.data["dam_height"]["status"], "OFFICIAL")

    def test_02_dam_crest(self):
        """TEST 2: Dam crest = 839.5 m"""
        self.assertEqual(self.data["dam_top_crest_elevation"]["value"], 839.5)
        self.assertEqual(self.data["dam_crest_level"]["value"], 839.5)
        self.assertEqual(self.data["dam_crest_level"]["label"], "Dam Crest / Top")

    def test_03_frl(self):
        """TEST 3: FRL = 830 m"""
        self.assertEqual(self.data["frl"]["value"], 830.0)
        self.assertEqual(self.data["frl"]["unit"], "m")
        self.assertEqual(self.data["frl"]["status"], "OFFICIAL")

    def test_04_mfl(self):
        """TEST 4: MFL = 835 m"""
        self.assertEqual(self.data["mfl"]["value"], 835.0)
        self.assertEqual(self.data["mfl"]["unit"], "m")
        self.assertEqual(self.data["mfl"]["status"], "OFFICIAL")

    def test_05_mddl(self):
        """TEST 5: MDDL = 740 m"""
        self.assertEqual(self.data["mddl"]["value"], 740.0)
        self.assertEqual(self.data["mddl"]["unit"], "m")
        self.assertEqual(self.data["mddl"]["status"], "OFFICIAL")

    def test_06_crest_length(self):
        """TEST 6: Crest length = 575 m"""
        self.assertEqual(self.data["crest_length"]["value"], 575.0)
        self.assertEqual(self.data["crest_length"]["unit"], "m")

    def test_07_top_width(self):
        """TEST 7: Top width = 25.5 m"""
        self.assertEqual(self.data["top_width"]["value"], 25.5)
        self.assertEqual(self.data["top_width"]["unit"], "m")
        self.assertEqual(self.data["top_width_abutments"]["value"], 30.5)

    def test_08_riverbed_width(self):
        """TEST 8: Riverbed width = 1125 m"""
        self.assertEqual(self.data["riverbed_base_width"]["value"], 1125.0)
        self.assertEqual(self.data["riverbed_base_width"]["unit"], "m")

    def test_09_gross_storage(self):
        """TEST 9: Gross storage = 3540 MCM"""
        self.assertEqual(self.data["gross_storage"]["value"], 3540.0)
        self.assertEqual(self.data["gross_storage"]["unit"], "MCM")

    def test_10_live_storage(self):
        """TEST 10: Live storage = 2615 MCM"""
        self.assertEqual(self.data["live_storage"]["value"], 2615.0)
        self.assertEqual(self.data["live_storage"]["unit"], "MCM")

    def test_11_pmf(self):
        """TEST 11: PMF = 15540 m³/s"""
        self.assertEqual(self.data["pmf_design_flood"]["value"], 15540.0)
        self.assertEqual(self.data["pmf_design_flood"]["unit"], "m³/s")

    def test_12_historical_recorded_flood(self):
        """TEST 12: Historical recorded flood = 3800 m³/s"""
        self.assertEqual(self.data["historical_recorded_flood"]["value"], 3800.0)
        self.assertEqual(self.data["historical_recorded_flood"]["unit"], "m³/s")

    def test_13_foundation_elevation_569_removed(self):
        """TEST 13: Foundation elevation 569.5 m MUST NOT exist as authoritative data."""
        self.assertIsNone(self.data["foundation_elevation"]["value"])
        self.assertEqual(self.data["foundation_elevation"]["status"], "SITE_SPECIFIC_REQUIRED")

    def test_14_830m_not_labelled_dam_crest(self):
        """TEST 14: 830 m MUST NOT be labelled dam crest."""
        frl_item = self.data["frl"]
        self.assertEqual(frl_item["value"], 830.0)
        self.assertNotIn("crest", frl_item["label"].lower())

    def test_15_835m_not_labelled_pmf(self):
        """TEST 15: 835 m MUST NOT be labelled PMF."""
        mfl_item = self.data["mfl"]
        self.assertEqual(mfl_item["value"], 835.0)
        self.assertNotEqual(mfl_item["label"], "PMF")

    def test_16_839m_not_labelled_mfl(self):
        """TEST 16: 839.5 m MUST NOT be labelled MFL."""
        crest_item = self.data["dam_crest_level"]
        self.assertEqual(crest_item["value"], 839.5)
        self.assertNotEqual(crest_item["label"], "MAXIMUM FLOOD LEVEL (MFL)")

    def test_17_flood_polygon_originates_from_hydraulic_depth(self):
        """TEST 17: Flood polygon must originate from hydraulic depth."""
        dem = np.zeros((10, 10))
        cfg = Hydrodynamic2DSolverConfig(dem_matrix=dem, simulation_duration_sec=300.0)
        solver = Hydrodynamic2DSolver(cfg)
        res = solver.run_simulation()
        wet_mask = np.array(res["summary_rasters"]["final_flood_extent_mask"])
        self.assertIsInstance(wet_mask, np.ndarray)
        self.assertEqual(wet_mask.shape, (10, 10))

    def test_18_no_static_geojson_flood_polygon(self):
        """TEST 18: Flood polygon must not be the old static GeoJSON polygon."""
        layer_svc = GIS2DLayerService()
        frame1 = layer_svc.get_simulation_frame_gis_data(time_step_min=5)
        frame2 = layer_svc.get_simulation_frame_gis_data(time_step_min=120)
        area1 = frame1["display_metrics"]["flooded_area_km2"]
        area2 = frame2["display_metrics"]["flooded_area_km2"]
        self.assertNotEqual(area1, area2)

    def test_19_changing_breach_width_changes_output(self):
        """TEST 19: Changing breach width must change simulation output."""
        m1 = DamBreachModel(breach_width_m=100.0, reservoir_level_m=830.0)
        m2 = DamBreachModel(breach_width_m=250.0, reservoir_level_m=830.0)
        q1 = m1.get_peak_discharge()
        q2 = m2.get_peak_discharge()
        self.assertNotEqual(q1, q2)

    def test_20_changing_reservoir_level_changes_output(self):
        """TEST 20: Changing reservoir level must change simulation output."""
        m1 = DamBreachModel(breach_width_m=180.0, reservoir_level_m=740.0)
        m2 = DamBreachModel(breach_width_m=180.0, reservoir_level_m=839.5)
        q1 = m1.get_peak_discharge()
        q2 = m2.get_peak_discharge()
        self.assertNotEqual(q1, q2)

    def test_21_changing_mannings_n_affects_hydraulic_output(self):
        """TEST 21: Changing Manning's n must affect hydraulic output where physically relevant."""
        layer_svc = GIS2DLayerService()
        f1 = layer_svc.get_simulation_frame_gis_data(time_step_min=30, scenario_params={"mannings_n": 0.015})
        f2 = layer_svc.get_simulation_frame_gis_data(time_step_min=30, scenario_params={"mannings_n": 0.080})
        v1 = f1["display_metrics"]["max_velocity_ms"]
        v2 = f2["display_metrics"]["max_velocity_ms"]
        self.assertNotEqual(v1, v2)

    def test_22_changing_timeline_step_changes_2d_frame(self):
        """TEST 22: Changing timeline step must change 2D flood frame."""
        layer_svc = GIS2DLayerService()
        f1 = layer_svc.get_simulation_frame_gis_data(time_step_min=5)
        f2 = layer_svc.get_simulation_frame_gis_data(time_step_min=60)
        self.assertNotEqual(f1["display_metrics"]["max_depth_m"], f2["display_metrics"]["max_depth_m"])

    def test_23_changing_timeline_step_changes_3d_frame(self):
        """TEST 23: Changing timeline step must change 3D flood frame."""
        layer_svc = GIS2DLayerService()
        f1 = layer_svc.get_simulation_frame_gis_data(time_step_min=10)
        f2 = layer_svc.get_simulation_frame_gis_data(time_step_min=180)
        self.assertNotEqual(f1["timeline_step_min"], f2["timeline_step_min"])

    def test_24_3d_water_surface_equation(self):
        """TEST 24: 3D water surface must use: terrain elevation + hydraulic depth."""
        dem_val = 650.0
        depth_val = 12.5
        wse = dem_val + depth_val
        self.assertEqual(wse, 662.5)

    def test_25_ai_page_does_not_claim_hecras_when_not_run(self):
        """TEST 25: AI page must not claim HEC-RAS results when HEC-RAS was not run."""
        status = asyncio.run(get_hecras_status())
        self.assertIn("status_banner", status)

    def test_26_gee_demo_does_not_display_live(self):
        """TEST 26: GEE DEMO data must not display LIVE status."""
        status = GEEAuth.get_status()
        if not status["authenticated"]:
            self.assertNotEqual(status["status"], "LIVE")
            self.assertIn("DEMO", status["message"].upper())

if __name__ == "__main__":
    unittest.main()
